import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { ValidationService } from './validation.service';

@Component({
  selector: 'app-registration-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent {
  registrationForm: FormGroup;
  submitted = false;
  submittedData: any;
  calculatedAge: number | null = null;
  calculatedTax: number | null = null;
  educationLevels = ["High School", "Associate's Degree", "Bachelor's Degree", "Master's Degree", "Doctorate"];

  constructor(private fb: FormBuilder) {
    this.registrationForm = this.fb.group({
      username: ['', [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20),
        Validators.pattern('^[a-zA-Z]+$')
      ]],
      email: ['', [
        Validators.required,
        Validators.email,
        Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$')
      ]],
      password: ['', [
        Validators.required,
        Validators.minLength(6),
        Validators.pattern('^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d@$!%*#?&]{6,}$')
      ]],
      confirmPassword: ['', [Validators.required, Validators.minLength(6)]],
      phone: ['', [
        Validators.required,
        Validators.pattern(/^(09|\+959)\d{7,9}$/)
      ]],
      dob: ['', [Validators.required, this.futureDateValidator.bind(this)]],
      education: ['', Validators.required],
      salary: ['', [Validators.required, Validators.min(0)]]
    }, { validator: this.passwordMatchValidator });
  }

  // Getters for form controls
  get username() { return this.registrationForm.get('username'); }
  get email() { return this.registrationForm.get('email'); }
  get password() { return this.registrationForm.get('password'); }
  get confirmPassword() { return this.registrationForm.get('confirmPassword'); }
  get phone() { return this.registrationForm.get('phone'); }
  get dob() { return this.registrationForm.get('dob'); }
  get education() { return this.registrationForm.get('education'); }
  get salary() { return this.registrationForm.get('salary'); }

  ngOnInit(): void {}

  // Custom validator to ensure the date of birth is not in the future and age is not under 13
  futureDateValidator: ValidatorFn = (control: AbstractControl) => {
    const dob = new Date(control.value);
    const today = new Date();
    if (dob > today) {
      return { futureDate: true };
    }
    const age = this.calculateAge(dob);
    if (age < 13) {
      return { underage: true };
    }
    return null;
  }

  // Update age when date of birth is changed
  onDobChange(event: any): void {
    const dobValue = event.target.value;
    if (dobValue) {
      const dateOfBirth = new Date(dobValue);
      const today = new Date();
      if (dateOfBirth <= today) {
        this.calculatedAge = this.calculateAge(dateOfBirth);
      } else {
        this.calculatedAge = null; 
      }
    } else {
      this.calculatedAge = null;
    }
  }

  // Calculate age based on date of birth
  calculateAge(dateOfBirth: Date): number {
    const today = new Date();
    let age = today.getFullYear() - dateOfBirth.getFullYear();
    const monthDifference = today.getMonth() - dateOfBirth.getMonth();
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < dateOfBirth.getDate())) {
      age--;
    }
    return age;
  }

  // Update tax when salary is changed
  onSalaryChange(event: any): void {
    const salaryValue = event.target.value;
    if (salaryValue && !isNaN(salaryValue)) {
      const salary = parseFloat(salaryValue);
      if (salary > 150000) {
        this.calculatedTax = salary * 0.05;
      } else {
        this.calculatedTax = 0;
      }
    } else {
      this.calculatedTax = null;
    }
  }

  // Custom validator for password match
  passwordMatchValidator: ValidatorFn = (form: AbstractControl) => {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    if (password !== confirmPassword) {
      form.get('confirmPassword')?.setErrors({ mismatch: true });
    } else {
      form.get('confirmPassword')?.setErrors(null);
    }
    return null;
  }

  // Handle form submission
  onSubmit() {
    this.submitted = true;
    if (this.registrationForm.valid) {
      const formValues = this.registrationForm.value;
      this.calculatedAge = this.calculateAge(new Date(formValues.dob));
      this.calculatedTax = formValues.salary > 150000 ? formValues.salary * 0.05 : 0;
      this.submittedData = { ...formValues, age: this.calculatedAge, tax: this.calculatedTax };
      console.log('Form Submitted', this.submittedData);
      this.registrationForm.reset();
      this.registrationForm.patchValue({ education: '' });
      this.calculatedAge = null;
      this.calculatedTax = null;
      this.submitted = false;
    } else {
      this.registrationForm.markAllAsTouched();
    }
  }

  // Handle form reset
  onReset(): void {
    this.submitted = false;
    this.registrationForm.reset();
    this.registrationForm.patchValue({ education: '' });
    this.calculatedAge = null;
    this.calculatedTax = null;
  }

  getErrorMessage(formControlName: string): string {
    const control = this.registrationForm.get(formControlName) as AbstractControl;
    return ValidationService.getFormControlErrors(control);
  }
}
