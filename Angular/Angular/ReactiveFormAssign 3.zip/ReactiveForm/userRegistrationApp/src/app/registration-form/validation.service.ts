import { FormControl, AbstractControl } from '@angular/forms';

export class ValidationService {
  static getValidatorErrorMessage(validatorName: string, validatorValue?: any): string {
    const config: any = {
      required: 'This field is required.',
      minlength: `Minimum length is ${validatorValue.requiredLength} characters.`,
      maxlength: `Maximum length is ${validatorValue.requiredLength} characters.`,
      email: 'Must be a valid email address.',
      pattern: 'Invalid format.',
      futureDate: 'Date of birth cannot be in the future.',
      underage: 'You must be at least 13 years old.',
      min: `Value must be at least ${validatorValue.min}.`,
      mismatch: 'Passwords do not match.'
    };
    return config[validatorName];
  }

  static getFormControlErrors(control: AbstractControl): string {
    for (const error in control.errors) {
      if (control.errors.hasOwnProperty(error)) {
        return ValidationService.getValidatorErrorMessage(error, control.errors[error]);
      }
    }
    return '';
  }
}
