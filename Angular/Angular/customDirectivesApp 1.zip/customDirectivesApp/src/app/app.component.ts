import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomInputComponent } from './custom-input/custom-input.component';
import { TableComponent } from './table/table.component';
import { HighlightDirective } from './highlight.directive';
import { UnlessDirective } from './unless.directive';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { LoopDirective } from './loop.directive';
import { MultiColorHighlightDirective } from './multi-color-highlight.directive';
import { HighlightWrapperComponent } from './highlight-wrapper/highlight-wrapper.component';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  imports: [
    CommonModule,
    CustomInputComponent,
    TableComponent,
    HighlightDirective,
    UnlessDirective,
    EmployeeListComponent,
    LoopDirective,
    MultiColorHighlightDirective,
    HighlightWrapperComponent 
  ]
})
export class AppComponent {
  inputValue: string = '';
  showContent: boolean = true;

  tableItems: any[] = [
    { name: 'Item 1', price: 10, quantity: 5 },
    { name: 'Item 2', price: 15, quantity: 3 },
    { name: 'Item 3', price: 20, quantity: 2 }
  ];

  employees: any[] = [
    { name: 'John Doe', position: 'Developer' },
    { name: 'Jane Smith', position: 'Designer' },
    { name: 'Jim Brown', position: 'Manager' }
  ];

  toggleContent(): void {
    this.showContent = !this.showContent;
  }

  currentColor: string = '';

  changeColor(color: string): void {
    this.currentColor = color; // Method to update currentColor
  }
}
