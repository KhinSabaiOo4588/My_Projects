import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoopDirective } from '../loop.directive'; 

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule, LoopDirective], 
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent {
  @Input() employees: any[] = [];
}
