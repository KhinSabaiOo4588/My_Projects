import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appLoop]',
  standalone: true
})
export class LoopDirective {
  private items: any[] = [];

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef
  ) {}

  @Input() set appLoopOf(items: any[]) {
    this.items = items;
    this.viewContainer.clear();
    items.forEach((item, index) => {
      this.viewContainer.createEmbeddedView(this.templateRef, {
        $implicit: item,
      // Provide the current item as an implicit context variable to the view.

      index: index
      // Provide the current index as part of the context to the view.
      });
    });
  }
}
