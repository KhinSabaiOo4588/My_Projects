import { MultiColorHighlightDirective } from './multi-color-highlight.directive';

describe('MultiColorHighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new MultiColorHighlightDirective();
    expect(directive).toBeTruthy();
  });
});
