import { Directive, ElementRef, Renderer2, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appMultiColorHighlight]',
  standalone: true
})
export class MultiColorHighlightDirective {
  @Input('appMultiColorHighlight') colors: string[] = []; // Accepts an array of colors for cycling
  @Input('appChangeColor') set changeColor(color: string) {
    if (color) {
      this.changeToColor(color); // Change to a specific color when input changes
    }
  }

  private colorIndex: number = 0;

  constructor(private el: ElementRef, private renderer: Renderer2) { }

  @HostListener('mouseenter') onMouseEnter() {
    this.cycleColors(); // Cycle through colors on mouse enter
  }

  @HostListener('click') onClick() {
    this.cycleColors(); // Cycle through colors on click
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.resetColor(); // Reset color on mouse leave
  }

  private cycleColors() {
    const color = this.colors[this.colorIndex] || 'lightgray'; // Get next color or default
    this.renderer.setStyle(this.el.nativeElement, 'background-color', color);
    this.colorIndex = (this.colorIndex + 1) % this.colors.length; // Update index for next color
  }

  private changeToColor(color: string) {
    this.renderer.setStyle(this.el.nativeElement, 'background-color', color); // Set to specific color
  }

  private resetColor() {
    this.renderer.removeStyle(this.el.nativeElement, 'background-color'); // Remove background color
  }
}
