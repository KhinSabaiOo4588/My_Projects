import { Component, ContentChild, AfterContentInit, ElementRef, Renderer2 } from '@angular/core';
import { HighlightDirective } from '../highlight.directive';

@Component({
  selector: 'app-highlight-wrapper',
  standalone: true,
  templateUrl: './highlight-wrapper.component.html',
  styleUrls: ['./highlight-wrapper.component.css'],
  imports: [HighlightDirective]
})
export class HighlightWrapperComponent implements AfterContentInit {
  @ContentChild(HighlightDirective, { read: ElementRef }) highlightElement!: ElementRef;

  constructor(private renderer: Renderer2) {}

  ngAfterContentInit(): void {
    if (this.highlightElement) {
      this.renderer.setStyle(this.highlightElement.nativeElement, 'border', '2px solid red');
    }
  }
}
