import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-custom-input',
  standalone: true,
  imports: [],
  templateUrl: './custom-input.component.html',
  styleUrl: './custom-input.component.css'
})
export class CustomInputComponent {
  @Input() value: string = '';
  @Output() valueChange = new EventEmitter<string>();

  onInputChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.valueChange.emit(input.value);
  }

  transformToUppercase(): void {
    this.value = this.value.toUpperCase();
    this.valueChange.emit(this.value);
  }

  transformToLowercase(): void {
    this.value = this.value.toLowerCase();
    this.valueChange.emit(this.value);
  }

  transformToCamelCase(): void {
    this.value = this.toCamelCase(this.value);
    this.valueChange.emit(this.value);
  }

  private toCamelCase(value: string): string {
    return value.replace(/\b\w/g, match => match.toUpperCase());
  }
}