import { UnlessDirective } from './unless.directive';

describe('UnlessDirective', () => {
  it('should create an instance', () => {
    const directive = new UnlessDirective();
    expect(directive).toBeTruthy();
  });
});
