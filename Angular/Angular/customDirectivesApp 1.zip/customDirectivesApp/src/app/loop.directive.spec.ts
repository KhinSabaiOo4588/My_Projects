import { LoopDirective } from './loop.directive';

describe('LoopDirective', () => {
  it('should create an instance', () => {
    const directive = new LoopDirective();
    expect(directive).toBeTruthy();
  });
});
